export * from './lib/index'
import YouTubePlayer from './lib/index'
export default YouTubePlayer
