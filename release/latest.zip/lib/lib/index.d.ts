import { PlayerMetadata, VideoData } from "./types";
import { YouTubeMediaPlayer } from "./player";
import { PlaylistPlayer } from "./playlist";
declare class YouTubePlayer {
    static createPlayer(source: VideoData, metadata: PlayerMetadata): YouTubeMediaPlayer;
    static createPlaylistPlayer(sources: VideoData[], root?: HTMLElement): PlaylistPlayer;
}
export * from "./types";
export default YouTubePlayer;
export { YouTubePlayer };
export * from "./player";
export * from "./playlist";
